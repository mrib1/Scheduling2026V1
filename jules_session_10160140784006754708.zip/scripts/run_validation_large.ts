
// Polyfill localStorage for Node
const localStorageMock = (function() {
  let store: Record<string, string> = {};
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => { store[key] = value.toString(); },
    removeItem: (key: string) => { delete store[key]; },
    clear: () => { store = {}; },
  };
})();

Object.defineProperty(global, 'localStorage', { value: localStorageMock });

import { runCsoAlgorithm } from '../services/csoService';
import { Client, Therapist, DayOfWeek, TherapistRole } from '../types';

async function runTest(numClients: number, numStaff: number) {
    console.log(`\n--- Running Test: ${numClients} Clients, ${numStaff} Staff ---`);
    
    const therapists: Therapist[] = [];
    for (let i = 1; i <= numStaff; i++) {
        let role: TherapistRole = "Technician";
        if (i % 10 === 0) role = "BCBA";
        else if (i % 10 === 1) role = "Clinical Fellow";
        else if (i % 10 === 2) role = "RBT";
        
        therapists.push({
            id: `t${i}`,
            name: `Therapist ${i}`,
            role: role,
            teamId: `team-${Math.floor(i/10)}`,
            qualifications: ["MD_MEDICAID", "RBT", "BCBA"],
            canProvideAlliedHealth: ["OT", "SLP"]
        });
    }

    const clients: Client[] = [];
    for (let i = 1; i <= numClients; i++) {
        clients.push({
            id: `c${i}`,
            name: `Client ${i}`,
            teamId: `team-${Math.floor(i/10)}`,
            insuranceRequirements: ["MD_MEDICAID"],
            alliedHealthNeeds: []
        });
    }

    const selectedDate = new Date(2025, 4, 19); // A Monday
    const result = await runCsoAlgorithm(clients, therapists, selectedDate, []);

    console.log(`Success: ${result.success}`);
    console.log(`Fitness: ${result.bestFitness.toFixed(2)}`);
    console.log(`Generations: ${result.generations}`);
    console.log(`Errors: ${result.finalValidationErrors.length}`);
    
    if (result.finalValidationErrors.length > 0) {
        console.log("First 5 Errors:");
        result.finalValidationErrors.slice(0, 5).forEach(e => console.log(` - ${e.message}`));
    }

    return result.finalValidationErrors.length === 0;
}

async function main() {
    try {
        console.time("Large Test");
        await runTest(40, 50);
        console.timeEnd("Large Test");
    } catch (e) {
        console.error(e);
        process.exit(1);
    }
}

main();
