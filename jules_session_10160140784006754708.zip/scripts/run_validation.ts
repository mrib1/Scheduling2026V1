
// Polyfill localStorage for Node
const localStorageMock = (function() {
  let store: Record<string, string> = {};
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => { store[key] = value.toString(); },
    removeItem: (key: string) => { delete store[key]; },
    clear: () => { store = {}; },
  };
})();

Object.defineProperty(global, 'localStorage', { value: localStorageMock });

import { runCsoAlgorithm } from '../services/csoService';
import { Client, Therapist, DayOfWeek, TherapistRole } from '../types';

async function runTest(numClients: number, numStaff: number) {
    console.log(`\n--- Running Test: ${numClients} Clients, ${numStaff} Staff ---`);
    
    const therapists: Therapist[] = [];
    for (let i = 1; i <= numStaff; i++) {
        let role: TherapistRole = "Technician";
        if (i === 1) role = "BCBA";
        else if (i === 2) role = "Clinical Fellow";
        else if (i === 3) role = "RBT";
        
        therapists.push({
            id: `t${i}`,
            name: `Therapist ${i}`,
            role: role,
            teamId: i <= 4 ? 'team-1' : 'team-2', // Two teams to allow staggering
            qualifications: ["MD_MEDICAID", "RBT", "BCBA"],
            canProvideAlliedHealth: ["OT", "SLP"]
        });
    }

    const clients: Client[] = [];
    for (let i = 1; i <= numClients; i++) {
        clients.push({
            id: `c${i}`,
            name: `Client ${i}`,
            teamId: i <= 3 ? 'team-1' : 'team-2',
            insuranceRequirements: ["MD_MEDICAID"],
            alliedHealthNeeds: []
        });
    }

    const selectedDate = new Date(2025, 4, 19); // A Monday
    const result = await runCsoAlgorithm(clients, therapists, selectedDate, []);

    console.log(`Success: ${result.success}`);
    console.log(`Fitness: ${result.bestFitness.toFixed(2)}`);
    console.log(`Generations: ${result.generations}`);
    console.log(`Errors: ${result.finalValidationErrors.length}`);
    
    if (result.finalValidationErrors.length > 0) {
        console.log("First 10 Errors:");
        result.finalValidationErrors.slice(0, 10).forEach(e => console.log(` - ${e.message}`));
    }

    // Check Indirect Time Priority
    const bcba = therapists.find(t => t.role === "BCBA")!;
    const cf = therapists.find(t => t.role === "Clinical Fellow")!;
    const rbt = therapists.find(t => t.role === "RBT")!;
    const tech = therapists.find(t => t.role === "Technician")!;

    const getIndirectTime = (tid: string) => 
        result.schedule?.filter(s => s.therapistId === tid && s.sessionType === 'IndirectTime')
        .reduce((sum, s) => sum + 30, 0) || 0;

    console.log(`BCBA Indirect: ${getIndirectTime(bcba.id)} mins`);
    console.log(`CF Indirect: ${getIndirectTime(cf.id)} mins`);
    console.log(`RBT Indirect: ${getIndirectTime(rbt.id)} mins`);
    console.log(`Tech Indirect: ${getIndirectTime(tech.id)} mins`);

    return result.finalValidationErrors.length === 0;
}

async function main() {
    try {
        const smallTest = await runTest(6, 8);
        
        if (smallTest) {
            console.log("\nSMALL TEST PASSED!");
        } else {
            console.log("\nSMALL TEST FAILED!");
        }
    } catch (e) {
        console.error(e);
        process.exit(1);
    }
}

main();
